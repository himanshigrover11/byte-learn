import React from 'react';
import './recordedvdo.css'


const recordedvdo = () => {
  return (
    <div>
      <div className='viddiv'>
      <iframe src="https://drive.google.com/file/d/1zXf7WU9Fj6MHR5gg_C7bD5dVeVB_n9ea/preview" className='vidm' allow="autoplay"></iframe>
      </div>
    </div>
  )
}

export default recordedvdo
