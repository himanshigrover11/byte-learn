import React from 'react'
import Screen from "../component/SplashScreen";

const SplashScreen = () => {
  return (
    <div>
      <Screen/>
    </div>
  )
}

export default SplashScreen;